<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Contacto;
class ContactoController extends Controller
{
    

public function index() {

return view('contacto');

}


public function mensaje(Request $request){

   // dd($request);
   /*
$this->validate($request,[
	'name'=>'required',
  'email'=>'required',
  'info_conocer'=>'required',
  'consulta'=>'required',
  'descripcion_consulta'=>'required|min:10'

  ]);
*/
  

$contacto= new Contacto;
$contacto->name= $request->get('name');
$contacto->email= $request->get('email');
$contacto->telefono= $request->get('telefono');
$contacto->info_conocer=$request->get('info_conocer');
$contacto->consulta= $request->get('consulta');
$contacto->descripcion_consulta= $request->get('descripcion_consulta');
$contacto->save();


return redirect()->route('contacto');
}




}
