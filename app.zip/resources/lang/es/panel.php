<?php

return [
    'site_title' => 'Click Saludable Express',
];
