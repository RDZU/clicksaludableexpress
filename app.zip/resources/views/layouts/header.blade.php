<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Click Saludable Express</title>
    <link rel="shortcut icon" href="{{asset('assets/img/logo-clicksaludableexpress.ico')}}">
    <meta name="description" content="Click Saludable Express, alimentos&nbsp;saludables, sin gluten ( gluten free) ,libres de tacc, sin azúcar (sugar Free) , veganos, orgánicos, NON/GMO,( no transgénicos), Libre de Lactosa" />
    <link rel="stylesheet" href="{{asset('assets/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800&amp;subset=latin-ext">
    <link rel="stylesheet" href="{{asset('assets/fonts/fontawesome-all.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/fonts/font-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/fonts/fontawesome5-overrides.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/best-carousel-slide.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Brands.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Footer-Dark.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css">
    
    <link rel="stylesheet" href="{{asset('assets/css/Simple-Slider.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
    <link rel="stylesheet" href="{{asset('assets/css/Lightbox-Gallery.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Navigation-Clean.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Navigation-with-Search.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Registration-Form-with-Photo.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/card-carousel.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/Social-Icons.css')}}">
    <link rel="stylesheet" href="{{asset('assets/jquery-ui/jquery-ui.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/styles.css')}}">
  
</head>

<body>
    <section id="top-header">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-2 col-xl-2 text-center"><a href="https://www.facebook.com/clicksaludableexpress-107186111415243" target="_blank"><i class="fab fa-facebook-square top-header"></i></a><a href="https://www.instagram.com/clicksaludableexpress/" target="_blank"><i class="fab fa-instagram top-header"></i></a></div>
                <div
                    class="col-md-12 col-lg-5 col-xl-5 offset-0 offset-md-0 offset-lg-0 text-center"><i class="fa fa-envelope top-email"></i><a class="text-success" data-bs-hover-animate="bounce" href="mailto:clicksaludableexpress@gmail.com" target="_blank"><span class="cabecera-correo"><strong>&nbsp; clicksaludableexpress@gmail.com</strong></span></a></div>
            <div
                class="col-md-12 col-lg-5 col-xl-5 text-center"><i class="fa fa-map-marker top-lugar"></i><span id="cabezera-lugar"><strong>&nbsp; Lecheria, Edo. Anzoátegui. Venezuela</strong></span></div>
        </div>
        </div>
    </section>
    <header>
        <nav class="navbar navbar-light navbar-expand-lg mobile">
            <div class="container"> 
                <a href="{{route('inicio')}}"><img id="logo"  class="img-fluid" src="{{asset('assets/img/logo-clicksaludableexpress.webp')}}"></a><a class="navbar-brand" href=""><br>
                </a>
                <button data-toggle="collapse" class="navbar-toggler .menu" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="nav navbar-nav mx-auto">
                        <li class="nav-item" role="presentation"><a class="nav-link text-success" href="{{route('inicio')}}" style="font-size: 18px;"><strong>Inicio</strong></a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link text-success" href="{{route('productos')}}" style="font-size: 18px;"><strong>Productos</strong></a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link text-success" href="{{route('marcas')}}" style="font-size: 18px;"><strong>Marcas</strong></a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link text-success border-secondary" href="{{route('about')}}" style="font-size: 18px;"><strong>Nosotros</strong></a></li>
                        <li class="nav-item" role="presentation"><a class="nav-link text-success" href="{{route('contacto')}}" style="font-size: 18px;"><strong>Contacto</strong></a></li>
                    </ul>
            </div>
            </div>
        </nav>
    </header>
