<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.product.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.products.update", [$product->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.product.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $product->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="description"><?php echo e(trans('cruds.product.fields.description')); ?></label>
                <textarea class="form-control ckeditor <?php echo e($errors->has('description') ? 'is-invalid' : ''); ?>" name="description" id="description"><?php echo old('description', $product->description); ?></textarea>
                <?php if($errors->has('description')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('description')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.description_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="marca_id"><?php echo e(trans('cruds.product.fields.marca')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('marca') ? 'is-invalid' : ''); ?>" name="marca_id" id="marca_id" required>
                    <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((old('marca_id') ? old('marca_id') : $product->marca->id ?? '') == $id ? 'selected' : ''); ?>><?php echo e($marca); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('marca')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('marca')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.marca_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="categories"><?php echo e(trans('cruds.product.fields.category')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('categories') ? 'is-invalid' : ''); ?>" name="categories[]" id="categories" multiple>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('categories', [])) || $product->categories->contains($id)) ? 'selected' : ''); ?>><?php echo e($category); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('categories')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('categories')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.category_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="etiquetas"><?php echo e(trans('cruds.product.fields.etiquetas')); ?></label>
                <div style="padding-bottom: 4px">
                    <span class="btn btn-info btn-xs select-all" style="border-radius: 0"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all" style="border-radius: 0"><?php echo e(trans('global.deselect_all')); ?></span>
                </div>
                <select class="form-control select2 <?php echo e($errors->has('etiquetas') ? 'is-invalid' : ''); ?>" name="etiquetas[]" id="etiquetas" multiple>
                    <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $etiquetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('etiquetas', [])) || $product->etiquetas->contains($id)) ? 'selected' : ''); ?>><?php echo e($etiquetas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('etiquetas')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('etiquetas')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.etiquetas_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="tipo_presentacion"><?php echo e(trans('cruds.product.fields.tipo_presentacion')); ?></label>
                <input class="form-control <?php echo e($errors->has('tipo_presentacion') ? 'is-invalid' : ''); ?>" type="text" name="tipo_presentacion" id="tipo_presentacion" value="<?php echo e(old('tipo_presentacion', $product->tipo_presentacion)); ?>" required>
                <?php if($errors->has('tipo_presentacion')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tipo_presentacion')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.tipo_presentacion_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="slug"><?php echo e(trans('cruds.product.fields.slug')); ?></label>
                <input class="form-control <?php echo e($errors->has('slug') ? 'is-invalid' : ''); ?>" type="text" name="slug" id="slug" value="<?php echo e(old('slug', $product->slug)); ?>" required>
                <?php if($errors->has('slug')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('slug')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.slug_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="envase"><?php echo e(trans('cruds.product.fields.envase')); ?></label>
                <input class="form-control <?php echo e($errors->has('envase') ? 'is-invalid' : ''); ?>" type="text" name="envase" id="envase" value="<?php echo e(old('envase', $product->envase)); ?>" required>
                <?php if($errors->has('envase')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('envase')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.envase_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="cantidad"><?php echo e(trans('cruds.product.fields.cantidad')); ?></label>
                <input class="form-control <?php echo e($errors->has('cantidad') ? 'is-invalid' : ''); ?>" type="text" name="cantidad" id="cantidad" value="<?php echo e(old('cantidad', $product->cantidad)); ?>" required>
                <?php if($errors->has('cantidad')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('cantidad')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.cantidad_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="largo"><?php echo e(trans('cruds.product.fields.largo')); ?></label>
                <input class="form-control <?php echo e($errors->has('largo') ? 'is-invalid' : ''); ?>" type="number" name="largo" id="largo" value="<?php echo e(old('largo', $product->largo)); ?>" step="1" required>
                <?php if($errors->has('largo')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('largo')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.largo_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="ancho"><?php echo e(trans('cruds.product.fields.ancho')); ?></label>
                <input class="form-control <?php echo e($errors->has('ancho') ? 'is-invalid' : ''); ?>" type="number" name="ancho" id="ancho" value="<?php echo e(old('ancho', $product->ancho)); ?>" step="1" required>
                <?php if($errors->has('ancho')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('ancho')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.ancho_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="alto"><?php echo e(trans('cruds.product.fields.alto')); ?></label>
                <input class="form-control <?php echo e($errors->has('alto') ? 'is-invalid' : ''); ?>" type="number" name="alto" id="alto" value="<?php echo e(old('alto', $product->alto)); ?>" step="1" required>
                <?php if($errors->has('alto')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('alto')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.alto_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="peso"><?php echo e(trans('cruds.product.fields.peso')); ?></label>
                <input class="form-control <?php echo e($errors->has('peso') ? 'is-invalid' : ''); ?>" type="text" name="peso" id="peso" value="<?php echo e(old('peso', $product->peso)); ?>" required>
                <?php if($errors->has('peso')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('peso')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.peso_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.product.fields.visible_home')); ?></label>
                <select class="form-control <?php echo e($errors->has('visible_home') ? 'is-invalid' : ''); ?>" name="visible_home" id="visible_home">
                    <option value disabled <?php echo e(old('visible_home', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Product::VISIBLE_HOME_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('visible_home', $product->visible_home) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('visible_home')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('visible_home')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.visible_home_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="descripcion_home"><?php echo e(trans('cruds.product.fields.descripcion_home')); ?></label>
                <input class="form-control <?php echo e($errors->has('descripcion_home') ? 'is-invalid' : ''); ?>" type="text" name="descripcion_home" id="descripcion_home" value="<?php echo e(old('descripcion_home', $product->descripcion_home)); ?>">
                <?php if($errors->has('descripcion_home')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('descripcion_home')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.descripcion_home_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.product.fields.stock')); ?></label>
                <select class="form-control <?php echo e($errors->has('stock') ? 'is-invalid' : ''); ?>" name="stock" id="stock">
                    <option value disabled <?php echo e(old('stock', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Product::STOCK_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('stock', $product->stock) === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('stock')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('stock')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.stock_helper')); ?></span>
            </div>

            <!--
            <div class="form-group">
                <label for="price"><?php echo e(trans('cruds.product.fields.price')); ?></label>
                <input class="form-control <?php echo e($errors->has('price') ? 'is-invalid' : ''); ?>" type="number" name="price" id="price" value="<?php echo e(old('price', $product->price)); ?>" step="0.01">
                <?php if($errors->has('price')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.price_helper')); ?></span>
            </div>

         
            <div class="form-group">
                <label for="photo"><?php echo e(trans('cruds.product.fields.photo')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>" id="photo-dropzone">
                </div>
                <?php if($errors->has('photo')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_helper')); ?></span>
            </div>
        -->
       
            <div class="form-group">
                <label class="required" for="image_frontal_link"><?php echo e(trans('cruds.product.fields.image_frontal_link')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_frontal_link') ? 'is-invalid' : ''); ?>" type="text" name="image_frontal_link" id="image_frontal_link" value="<?php echo e(old('image_frontal_link', $product->image_frontal_link)); ?>" required>
                <?php if($errors->has('image_frontal_link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_frontal_link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_frontal_link_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_frontal_title"><?php echo e(trans('cruds.product.fields.image_frontal_title')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_frontal_title') ? 'is-invalid' : ''); ?>" type="text" name="image_frontal_title" id="image_frontal_title" value="<?php echo e(old('image_frontal_title', $product->image_frontal_title)); ?>">
                <?php if($errors->has('image_frontal_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_frontal_title')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_frontal_title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_frontal_alt"><?php echo e(trans('cruds.product.fields.image_frontal_alt')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_frontal_alt') ? 'is-invalid' : ''); ?>" type="text" name="image_frontal_alt" id="image_frontal_alt" value="<?php echo e(old('image_frontal_alt', $product->image_frontal_alt)); ?>">
                <?php if($errors->has('image_frontal_alt')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_frontal_alt')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_frontal_alt_helper')); ?></span>
            </div>

            <!--
            <div class="form-group">
                <label for="photo_reverso"><?php echo e(trans('cruds.product.fields.photo_reverso')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo_reverso') ? 'is-invalid' : ''); ?>" id="photo_reverso-dropzone">
                </div>
                <?php if($errors->has('photo_reverso')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_reverso')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_reverso_helper')); ?></span>
            </div>
        -->

            <div class="form-group">
                <label class="required" for="image_reverso_link"><?php echo e(trans('cruds.product.fields.image_reverso_link')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_reverso_link') ? 'is-invalid' : ''); ?>" type="text" name="image_reverso_link" id="image_reverso_link" value="<?php echo e(old('image_reverso_link', $product->image_reverso_link)); ?>" required>
                <?php if($errors->has('image_reverso_link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_reverso_link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_reverso_link_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_reverso_title"><?php echo e(trans('cruds.product.fields.image_reverso_title')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_reverso_title') ? 'is-invalid' : ''); ?>" type="text" name="image_reverso_title" id="image_reverso_title" value="<?php echo e(old('image_reverso_title', $product->image_reverso_title)); ?>">
                <?php if($errors->has('image_reverso_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_reverso_title')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_reverso_title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_reverso_alt"><?php echo e(trans('cruds.product.fields.image_reverso_alt')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_reverso_alt') ? 'is-invalid' : ''); ?>" type="text" name="image_reverso_alt" id="image_reverso_alt" value="<?php echo e(old('image_reverso_alt', $product->image_reverso_alt)); ?>">
                <?php if($errors->has('image_reverso_alt')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_reverso_alt')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.image_reverso_alt_helper')); ?></span>
            </div>
            <!--
            <div class="form-group">
                <label for="photo_min_reverso"><?php echo e(trans('cruds.product.fields.photo_min_reverso')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo_min_reverso') ? 'is-invalid' : ''); ?>" id="photo_min_reverso-dropzone">
                </div>
                <?php if($errors->has('photo_min_reverso')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_min_reverso')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_min_reverso_helper')); ?></span>
            </div>
        -->

            <div class="form-group">
                <label for="photo_min_reverso_link"><?php echo e(trans('cruds.product.fields.photo_min_reverso_link')); ?></label>
                <input class="form-control <?php echo e($errors->has('photo_min_reverso_link') ? 'is-invalid' : ''); ?>" type="text" name="photo_min_reverso_link" id="photo_min_reverso_link" value="<?php echo e(old('photo_min_reverso_link', $product->photo_min_reverso_link)); ?>">
                <?php if($errors->has('photo_min_reverso_link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_min_reverso_link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_min_reverso_link_helper')); ?></span>
            </div>

            <div class="form-group">
                <label for="photo_link_reverso_title"><?php echo e(trans('cruds.product.fields.photo_link_reverso_title')); ?></label>
                <input class="form-control <?php echo e($errors->has('photo_link_reverso_title') ? 'is-invalid' : ''); ?>" type="text" name="photo_link_reverso_title" id="photo_link_reverso_title" value="<?php echo e(old('photo_link_reverso_title', $product->photo_link_reverso_title)); ?>">
                <?php if($errors->has('photo_link_reverso_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_link_reverso_title')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_link_reverso_title_helper')); ?></span>
            </div>

<!--
            <div class="form-group">
                <label for="photo_link_reverso_alt"><?php echo e(trans('cruds.product.fields.photo_link_reverso_alt')); ?></label>
                <input class="form-control <?php echo e($errors->has('photo_link_reverso_alt') ? 'is-invalid' : ''); ?>" type="text" name="photo_link_reverso_alt" id="photo_link_reverso_alt" value="<?php echo e(old('photo_link_reverso_alt', $product->photo_link_reverso_alt)); ?>">
                <?php if($errors->has('photo_link_reverso_alt')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_link_reverso_alt')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_link_reverso_alt_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="photo_min_frontal"><?php echo e(trans('cruds.product.fields.photo_min_frontal')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo_min_frontal') ? 'is-invalid' : ''); ?>" id="photo_min_frontal-dropzone">
                </div>
                <?php if($errors->has('photo_min_frontal')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_min_frontal')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_min_frontal_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="photo_min_frontal_link"><?php echo e(trans('cruds.product.fields.photo_min_frontal_link')); ?></label>
                <input class="form-control <?php echo e($errors->has('photo_min_frontal_link') ? 'is-invalid' : ''); ?>" type="text" name="photo_min_frontal_link" id="photo_min_frontal_link" value="<?php echo e(old('photo_min_frontal_link', $product->photo_min_frontal_link)); ?>">
                <?php if($errors->has('photo_min_frontal_link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_min_frontal_link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_min_frontal_link_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="photo_link_frontal_title"><?php echo e(trans('cruds.product.fields.photo_link_frontal_title')); ?></label>
                <input class="form-control <?php echo e($errors->has('photo_link_frontal_title') ? 'is-invalid' : ''); ?>" type="text" name="photo_link_frontal_title" id="photo_link_frontal_title" value="<?php echo e(old('photo_link_frontal_title', $product->photo_link_frontal_title)); ?>">
                <?php if($errors->has('photo_link_frontal_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_link_frontal_title')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_link_frontal_title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="photo_link_frontal_alt"><?php echo e(trans('cruds.product.fields.photo_link_frontal_alt')); ?></label>
                <input class="form-control <?php echo e($errors->has('photo_link_frontal_alt') ? 'is-invalid' : ''); ?>" type="text" name="photo_link_frontal_alt" id="photo_link_frontal_alt" value="<?php echo e(old('photo_link_frontal_alt', $product->photo_link_frontal_alt)); ?>">
                <?php if($errors->has('photo_link_frontal_alt')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo_link_frontal_alt')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.product.fields.photo_link_frontal_alt_helper')); ?></span>
            </div>

        -->
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
  function SimpleUploadAdapter(editor) {
    editor.plugins.get('FileRepository').createUploadAdapter = function(loader) {
      return {
        upload: function() {
          return loader.file
            .then(function (file) {
              return new Promise(function(resolve, reject) {
                // Init request
                var xhr = new XMLHttpRequest();
                xhr.open('POST', '/admin/products/ckmedia', true);
                xhr.setRequestHeader('x-csrf-token', window._token);
                xhr.setRequestHeader('Accept', 'application/json');
                xhr.responseType = 'json';

                // Init listeners
                var genericErrorText = `Couldn't upload file: ${ file.name }.`;
                xhr.addEventListener('error', function() { reject(genericErrorText) });
                xhr.addEventListener('abort', function() { reject() });
                xhr.addEventListener('load', function() {
                  var response = xhr.response;

                  if (!response || xhr.status !== 201) {
                    return reject(response && response.message ? `${genericErrorText}\n${xhr.status} ${response.message}` : `${genericErrorText}\n ${xhr.status} ${xhr.statusText}`);
                  }

                  $('form').append('<input type="hidden" name="ck-media[]" value="' + response.id + '">');

                  resolve({ default: response.url });
                });

                if (xhr.upload) {
                  xhr.upload.addEventListener('progress', function(e) {
                    if (e.lengthComputable) {
                      loader.uploadTotal = e.total;
                      loader.uploaded = e.loaded;
                    }
                  });
                }

                // Send request
                var data = new FormData();
                data.append('upload', file);
                data.append('crud_id', '<?php echo e($product->id ?? 0); ?>');
                xhr.send(data);
              });
            })
        }
      };
    }
  }

  var allEditors = document.querySelectorAll('.ckeditor');
  for (var i = 0; i < allEditors.length; ++i) {
    ClassicEditor.create(
      allEditors[i], {
        extraPlugins: [SimpleUploadAdapter]
      }
    );
  }
});
</script>

<script>
    Dropzone.options.photoDropzone = {
    url: '<?php echo e(route('admin.products.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo"]').remove()
      $('form').append('<input type="hidden" name="photo" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($product) && $product->photo): ?>
      var file = <?php echo json_encode($product->photo); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<script>
    Dropzone.options.photoReversoDropzone = {
    url: '<?php echo e(route('admin.products.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo_reverso"]').remove()
      $('form').append('<input type="hidden" name="photo_reverso" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo_reverso"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($product) && $product->photo_reverso): ?>
      var file = <?php echo json_encode($product->photo_reverso); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo_reverso" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<script>
    Dropzone.options.photoMinReversoDropzone = {
    url: '<?php echo e(route('admin.products.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo_min_reverso"]').remove()
      $('form').append('<input type="hidden" name="photo_min_reverso" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo_min_reverso"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($product) && $product->photo_min_reverso): ?>
      var file = <?php echo json_encode($product->photo_min_reverso); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo_min_reverso" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<script>
    Dropzone.options.photoMinFrontalDropzone = {
    url: '<?php echo e(route('admin.products.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo_min_frontal"]').remove()
      $('form').append('<input type="hidden" name="photo_min_frontal" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo_min_frontal"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($product) && $product->photo_min_frontal): ?>
      var file = <?php echo json_encode($product->photo_min_frontal); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo_min_frontal" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>