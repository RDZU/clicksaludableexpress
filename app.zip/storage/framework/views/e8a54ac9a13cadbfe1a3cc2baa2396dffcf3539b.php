<?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





    

<div class="photo-gallery">
    <div class="container" style="margin-top:100px; margin-bottom:60px;">
        <div class="intro">
            <h2 class="text-center"></h2>
            <p class="text-center"></p>
        </div>
        <div class="row photos">

            <?php $__currentLoopData = $marcas_logo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marcas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
            <div class="col-sm-6 col-md-4 col-lg-3 item"><a data-lightbox="photos" href="<?php echo e(asset('imagen/'.$marcas->image_link)); ?>"><img class="img-fluid" src="<?php echo e(asset('imagen/'.$marcas->image_link)); ?>" alt="<?php echo e($marcas->image_alt); ?>" title="<?php echo e($marcas->image_title); ?>"></a></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

</div>

<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/marcas.blade.php ENDPATH**/ ?>