
<?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="text-center" id="header-productos"><strong>Nuestros Productos <span style="color:#24A62D">.</span></strong></h1>

    

<ul class="nav nav-pills mb-3 " id="pills-tab" role="tablist">
  <li class="nav-item">
    <a class="nav-link text-success active" id="pills-todos-tab" data-toggle="pill" href="#pills-todos" role="tab" aria-controls="pills-home" aria-selected="true"><strong>Todos</strong></a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-success" id="pills-sin-gluten-tab" data-toggle="pill" href="#pills-sin-gluten" role="tab" aria-controls="pills-profile" aria-selected="false"><strong>Sin gluten</strong></a>
  </li>
  <li class="nav-item">
    <a class="nav-link text-success" id="pills-sin-azucar-tab" data-toggle="pill" href="#pills-sin-azucar" role="tab" aria-controls="pills-contact" aria-selected="false"><strong>Sin Azúcar</strong></a>
  </li>
    
    <li class="nav-item">
    <a class="nav-link text-success" id="pills-salados-tab" data-toggle="pill" href="#pills-salados" role="tab" aria-controls="pills-contact" aria-selected="false"><strong>Salados </strong></a>
  </li>
    
    <li class="nav-item">
    <a class="nav-link text-success" id="pills-harinas-tab" data-toggle="pill" href="#pills-harinas" role="tab" aria-controls="pills-contact" aria-selected="false"><strong>Harinas y Premezclas</strong> </a>
  </li>
    <li class="nav-item">
    <a class="nav-link text-success" id="pills-almacen-tab" data-toggle="pill" href="#pills-almacen" role="tab" aria-controls="pills-contact" aria-selected="false"><strong>Almacén</strong></a>
  </li>
</ul>

    <section class="galeria-productos" >

<div class="tab-content" id="pills-tabContent">
  <div class="tab-pane fade show active" id="pills-todos" role="tabpanel" aria-labelledby="pills-todos-tab">



        <div class="container py-lg-5">
            <div class="row">
          <!-- CATEGORIA TODOS -->  
<?php $__currentLoopData = $productos_todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                <div class="col-sm-12 col-md-6  col-xl-4">
                    <ul class="list-unstyled clearfix p-0  row">
                        <li class="lista-producto">
                        <span class="image-block">
                        <a href="<?php echo e(route('productos.slug', [$todos->slug])); ?>"> 
                            
                            <div class="content-overlay"></div><img class="img-fluid" src="<?php echo e(asset('imagen/'.$todos->image_frontal_link)); ?>" alt="<?php echo e($todos->image_frontal_alt); ?>" title="<?php echo e($todos->image_frontal_title); ?>">
                        <div class="content-details fadeIn-bottom">
                            <h3><?php echo e($todos->name); ?></h3>
                            <div id="content-logo"><img class="img-fluid" src="<?php echo e(asset('assets/img/logo-clicksaludableexpress.webp')); ?>"  width="200" height="200">
                                <h3 ><?php echo e($todos->tipo_presentacion); ?></h3>
                                    <h3>Ver ficha <i class="fa fa-search"></i></h3>
                            </div>
                        </div></a>
    
                    </span>
    
                    </li>
                    </ul>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
       
        </div>
      
  </div>
  <div class="tab-pane fade" id="pills-sin-gluten" role="tabpanel" aria-labelledby="pills-sin-gluten-tab">





    <div class="container py-lg-5">
      <div class="row">

          <!-- CATEGORIA SIN GLUTEN -->
<?php $__currentLoopData = $productos_sin_gluten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-sm-12 col-md-6  col-xl-4">
              <ul class="list-unstyled clearfix p-0  row">
                  <li class="lista-producto">
                  <span class="image-block">
                  <a href="<?php echo e(route('productos.slug', [$todos->slug])); ?>"> 
                      
                      <div class="content-overlay"></div><img class="img-fluid" src="<?php echo e(asset('imagen/'.$todos->image_frontal_link)); ?>" alt="<?php echo e($todos->image_frontal_alt); ?>" title="<?php echo e($todos->image_frontal_title); ?>">
                  <div class="content-details fadeIn-bottom">
                      <h3><?php echo e($todos->name); ?></h3>
                      <div id="content-logo"><img class="img-fluid" src="<?php echo e(asset('assets/img/logo-clicksaludableexpress.webp')); ?>"  width="200" height="200">
                          <h3 ><?php echo e($todos->tipo_presentacion); ?></h3>
                              <h3>Ver ficha <i class="fa fa-search"></i></h3>
                      </div>
                  </div></a>

              </span>

              </li>
              </ul>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
 
  </div>




  </div>
  <div class="tab-pane fade" id="pills-sin-azucar" role="tabpanel" aria-labelledby="pills-sin-azucar-tab">


    <div class="container py-lg-5">
        <div class="row">

            <!-- CATEGORIA SIN AZUCAR -->
  <?php $__currentLoopData = $productos_sin_azucar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
            <div class="col-sm-12 col-md-6  col-xl-4">
                <ul class="list-unstyled clearfix p-0  row">
                    <li class="lista-producto">
                    <span class="image-block">
                    <a href="<?php echo e(route('productos.slug', [$todos->slug])); ?>"> 
                        
                        <div class="content-overlay"></div><img class="img-fluid" src="<?php echo e(asset('imagen/'.$todos->image_frontal_link)); ?>" alt="<?php echo e($todos->image_frontal_alt); ?>" title="<?php echo e($todos->image_frontal_title); ?>">
                    <div class="content-details fadeIn-bottom">
                        <h3><?php echo e($todos->name); ?></h3>
                        <div id="content-logo"><img class="img-fluid" src="<?php echo e(asset('assets/img/logo-clicksaludableexpress.webp')); ?>"  width="200" height="200">
                            <h3 ><?php echo e($todos->tipo_presentacion); ?></h3>
                                <h3>Ver ficha <i class="fa fa-search"></i></h3>
                        </div>
                    </div></a>
  
                </span>
  
                </li>
                </ul>
  
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
        </div>
   
    </div>


</div>
    <div class="tab-pane fade" id="pills-salados" role="tabpanel" aria-labelledby="pills-salados-tab"> 



      <div class="container py-lg-5">
        <div class="row">

            <!-- CATEGORIA SALADOS -->
<?php $__currentLoopData = $productos_salados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-sm-12 col-md-6  col-xl-4">
                <ul class="list-unstyled clearfix p-0  row">
                    <li class="lista-producto">
                    <span class="image-block">
                    <a href="<?php echo e(route('productos.slug', [$todos->slug])); ?>"> 
                        
                        <div class="content-overlay"></div><img class="img-fluid" src="<?php echo e(asset('imagen/'.$todos->image_frontal_link)); ?>" alt="<?php echo e($todos->image_frontal_alt); ?>" title="<?php echo e($todos->image_frontal_title); ?>">
                    <div class="content-details fadeIn-bottom">
                        <h3><?php echo e($todos->name); ?></h3>
                        <div id="content-logo"><img class="img-fluid" src="<?php echo e(asset('assets/img/logo-clicksaludableexpress.webp')); ?>"  width="200" height="200">
                            <h3 ><?php echo e($todos->tipo_presentacion); ?></h3>
                                <h3>Ver ficha <i class="fa fa-search"></i></h3>
                        </div>
                    </div></a>

                </span>

                </li>
                </ul>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
   
    </div>



    </div>

    <div class="tab-pane fade" id="pills-harinas" role="tabpanel" aria-labelledby="pills-harinas-tab">



        <div class="container py-lg-5">
            <div class="row">
                
                <!-- CATEGORIA HARINAS Y MEZCLA -->
    <?php $__currentLoopData = $productos_HarinasyPremezclas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                <div class="col-sm-12 col-md-6  col-xl-4">
                    <ul class="list-unstyled clearfix p-0  row">
                        <li class="lista-producto">
                        <span class="image-block">
                        <a href="<?php echo e(route('productos.slug', [$todos->slug])); ?>"> 
                            
                            <div class="content-overlay"></div><img class="img-fluid" src="<?php echo e(asset('imagen/'.$todos->image_frontal_link)); ?>" alt="<?php echo e($todos->image_frontal_alt); ?>" title="<?php echo e($todos->image_frontal_title); ?>">
                        <div class="content-details fadeIn-bottom">
                            <h3><?php echo e($todos->name); ?></h3>
                            <div id="content-logo"><img class="img-fluid" src="<?php echo e(asset('assets/img/logo-clicksaludableexpress.webp')); ?>"  width="200" height="200">
                                <h3 ><?php echo e($todos->tipo_presentacion); ?></h3>
                                    <h3>Ver ficha <i class="fa fa-search"></i></h3>
                            </div>
                        </div></a>
    
                    </span>
    
                    </li>
                    </ul>
    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            </div>
       
        </div>
    




    </div>
    <div class="tab-pane fade" id="pills-almacen" role="tabpanel" aria-labelledby="pills-almacen-tab">



        <div class="container py-lg-5">
            <div class="row">
                <!-- CATEGORIA HARINAS Y MEZCLA -->
    <?php $__currentLoopData = $productos_almacen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                <div class="col-sm-12 col-md-6  col-xl-4">
                    <ul class="list-unstyled clearfix p-0  row">
                        <li class="lista-producto">
                        <span class="image-block">
                        <a href="<?php echo e(route('productos.slug', [$todos->slug])); ?>"> 
                            
                            <div class="content-overlay"></div><img class="img-fluid" src="<?php echo e(asset('assets/img/oreo.png')); ?>" width="338" height="338">
                        <div class="content-details fadeIn-bottom">
                            <h3><?php echo e($todos->name); ?></h3>
                            <div id="content-logo"><img class="img-fluid" src="<?php echo e(asset('assets/img/logo-clicksaludableexpress.webp')); ?>"  width="200" height="200">
                                <h3 ><?php echo e($todos->tipo_presentacion); ?></h3>
                                    <h3>Ver ficha <i class="fa fa-search"></i></h3>
                            </div>
                        </div></a>
    
                    </span>
    
                    </li>
                    </ul>
    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
            </div>
       
        </div>




    </div>
</div>
   

</section>




    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/productos.blade.php ENDPATH**/ ?>