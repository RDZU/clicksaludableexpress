<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.product.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.products.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($product->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.name')); ?>

                        </th>
                        <td>
                            <?php echo e($product->name); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.description')); ?>

                        </th>
                        <td>
                            <?php echo $product->description; ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.marca')); ?>

                        </th>
                        <td>
                            <?php echo e($product->marca->name ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.category')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($category->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.etiquetas')); ?>

                        </th>
                        <td>
                            <?php $__currentLoopData = $product->etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $etiquetas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="label label-info"><?php echo e($etiquetas->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.tipo_presentacion')); ?>

                        </th>
                        <td>
                            <?php echo e($product->tipo_presentacion); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.slug')); ?>

                        </th>
                        <td>
                            <?php echo e($product->slug); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.envase')); ?>

                        </th>
                        <td>
                            <?php echo e($product->envase); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.cantidad')); ?>

                        </th>
                        <td>
                            <?php echo e($product->cantidad); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.largo')); ?>

                        </th>
                        <td>
                            <?php echo e($product->largo); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.ancho')); ?>

                        </th>
                        <td>
                            <?php echo e($product->ancho); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.alto')); ?>

                        </th>
                        <td>
                            <?php echo e($product->alto); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.peso')); ?>

                        </th>
                        <td>
                            <?php echo e($product->peso); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.visible_home')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Product::VISIBLE_HOME_SELECT[$product->visible_home] ?? ''); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.descripcion_home')); ?>

                        </th>
                        <td>
                            <?php echo e($product->descripcion_home); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.stock')); ?>

                        </th>
                        <td>
                            <?php echo e(App\Models\Product::STOCK_SELECT[$product->stock] ?? ''); ?>

                        </td>
                    </tr>
                   <!--  <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.price')); ?>

                        </th>
                        <td>
                            <?php echo e($product->price); ?>

                        </td>
                    </tr>
                


                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo')); ?>

                        </th>
                        <td>
                            <?php if($product->photo): ?>
                                <a href="<?php echo e($product->photo->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($product->photo->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>

                -->

                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.image_frontal_link')); ?>

                        </th>
                        <td>
                            <?php echo e($product->image_frontal_link); ?>

                        </td>
                    </tr>


                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.image_frontal_title')); ?>

                        </th>
                        <td>
                            <?php echo e($product->image_frontal_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.image_frontal_alt')); ?>

                        </th>
                        <td>
                            <?php echo e($product->image_frontal_alt); ?>

                        </td>
                    </tr>

                    <!--
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_reverso')); ?>

                        </th>
                        <td>
                            <?php if($product->photo_reverso): ?>
                                <a href="<?php echo e($product->photo_reverso->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($product->photo_reverso->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>

                -->

                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.image_reverso_link')); ?>

                        </th>
                        <td>
                            <?php echo e($product->image_reverso_link); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.image_reverso_title')); ?>

                        </th>
                        <td>
                            <?php echo e($product->image_reverso_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.image_reverso_alt')); ?>

                        </th>
                        <td>
                            <?php echo e($product->image_reverso_alt); ?>

                        </td>
                    </tr>

                    <!--
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_min_reverso')); ?>

                        </th>
                        <td>
                            <?php if($product->photo_min_reverso): ?>
                                <a href="<?php echo e($product->photo_min_reverso->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($product->photo_min_reverso->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>

                -->

                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_min_reverso_link')); ?>

                        </th>
                        <td>
                            <?php echo e($product->photo_min_reverso_link); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_link_reverso_title')); ?>

                        </th>
                        <td>
                            <?php echo e($product->photo_link_reverso_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_link_reverso_alt')); ?>

                        </th>
                        <td>
                            <?php echo e($product->photo_link_reverso_alt); ?>

                        </td>
                    </tr>
                    <!--
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_min_frontal')); ?>

                        </th>
                        <td>
                            <?php if($product->photo_min_frontal): ?>
                                <a href="<?php echo e($product->photo_min_frontal->getUrl()); ?>" target="_blank" style="display: inline-block">
                                    <img src="<?php echo e($product->photo_min_frontal->getUrl('thumb')); ?>">
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_min_frontal_link')); ?>

                        </th>
                        <td>
                            <?php echo e($product->photo_min_frontal_link); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_link_frontal_title')); ?>

                        </th>
                        <td>
                            <?php echo e($product->photo_link_frontal_title); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.product.fields.photo_link_frontal_alt')); ?>

                        </th>
                        <td>
                            <?php echo e($product->photo_link_frontal_alt); ?>

                        </td>
                    </tr>

                -->
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.products.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/admin/products/show.blade.php ENDPATH**/ ?>