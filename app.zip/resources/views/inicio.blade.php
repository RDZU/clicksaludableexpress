@include('layouts/header')


<div class="container">
    <div class="row">
      

        <div class="col-12">
          @if ($message = Session::get('error'))

    <div class="alert alert-danger alert-block" style="text-align: center;">
    
      <button type="button" class="close" data-dismiss="alert">×</button>	
    
            <strong>{{ $message }}</strong>
    
    </div>
    
    @endif
          <form action="{{route('mostrar.productos')}}" method="get">
            <div class="input-group">
                <div class="input-group-prepend"><span class="input-group-text">Buscar:</span></div><input required id="search" name="search" class="form-control" type="text">
                <div class="input-group-append"><button class="btn btn-success" type="submit"><i class="fa fa-search"></i></button></div>
            </div>
          </form>
        </div>
        </div >
    </div>
    

    <section id="inicio-slider">
    <div class="row">
        <div class="col-12">
            

            <div class="simple-slider">
                <div class="swiper-container">
                  <div class="swiper-wrapper">
                    <div class="swiper-slide" style="background-image:url(assets/img/JJJJ.PNG);"></div>
                    <div class="swiper-slide" style="background-image:url(assets/img/lakANTO.jpg);"></div>
                    <div class="swiper-slide" style="background-image:url(assets/img/hacendado.png);"></div>
                  </div>
                  
                </div>
              
              </div>

        </div>
    </div>

</section>



<div class="brands2">

    <div class="row">
  
        <div class="col">
            <div class="brands_slider_container">
                <div class="owl-carousel owl-theme brands_slider">
                   
                  @foreach ($marcas_logo as $marcas)                                                        
                  <div class="owl-item">
                      <div class="brands_item d-flex flex-column justify-content-center"><img src="{{asset('assets/img/'.$marcas->image_link)}}" alt="{{$marcas->image_alt}}" title="{{$marcas->image_title}}"></div>
                  </div>
                  @endforeach
                  
                </div> <!-- Brands Slider Navigation -->
                 <div class="brands_nav brands_prev"><i class="fas fa-chevron-left"></i></div>
                <div class="brands_nav brands_next"><i class="fas fa-chevron-right"></i></div>
            </div>
        </div>
    </div>

</div>

<section id="listado-productos">
   
<div class="container" >



  <div class="container-fluid">
    <h1 id="header-productos" class="text-center mb-3">Click Saludable Express te recomienda</h1>
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner row w-100 mx-auto">
          
        <div class="carousel-item col-md-4 active">
          <div class="card">
            <img class="card-img-top img-fluid" src="assets/img/oreo.png" alt="Card image cap">
            <div class="card-body">
              <h4 class="card-title">Card 1</h4>
              <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              <p class="card-text"><small class="text-muted"><img src="{{asset('assets/img/non-gmo.png')}}"><img src="{{asset('assets/img/sin-azucar.png')}}"><img src="{{asset('assets/img/sin-gluten.png')}}"><img src="{{asset('assets/img/sin-tacc.png')}}"><img src="{{asset('assets/img/vegano.png')}}"></small></p>
            </div>
          </div>
        </div>
        
        @foreach($products as $key => $product)
            
        <div class="carousel-item col-md-4">
          <div class="card">
        
            <a href="{{ route('productos.slug', $product->slug) }}">   <img class="card-img-top img-fluid" src="{{asset('imagen/'.$product->image_frontal_link)}}" alt="{{$product->image_frontal_alt}}" title="{{$product->image_frontal_title}}"> 
           </a>
            <div class="card-body">
              <h4 class="card-title">{{$product->name}}</h4>
              <p class="card-text">{{$product->descripcion_home}}</p>
              <p class="card-text"><small class="text-muted"> @foreach($product->etiquetas as $key => $item)
                <img src="{{asset('assets/img/'.$item->tag_link)}}" alt="{{$item->tag_alt}}" title="{{$item->tag_title}}"> 
             
            
            @endforeach
          
          </small></p>
            </div>
          </div>
        </div>
        
        @endforeach
       
      
       
        
      
      </div>
      <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>



</div>

</section>


@include('layouts/footer')