@include('layouts/header')

pantalla numero 1

<a class="btn btn-primary" href="" role="button">Link</a>


@include('layouts/footer')