@include('layouts/header')





    

<div class="photo-gallery">
    <div class="container" style="margin-top:100px; margin-bottom:60px;">
        <div class="intro">
            <h2 class="text-center"></h2>
            <p class="text-center"></p>
        </div>
        <div class="row photos">

            @foreach ($marcas_logo as $marcas)
                
            
            <div class="col-sm-6 col-md-4 col-lg-3 item"><a data-lightbox="photos" href="{{asset('imagen/'.$marcas->image_link)}}"><img class="img-fluid" src="{{asset('imagen/'.$marcas->image_link)}}" alt="{{$marcas->image_alt}}" title="{{$marcas->image_title}}"></a></div>
  @endforeach
    </div>
</div>

</div>

@include('layouts/footer')