<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.productTag.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.product-tags.update", [$productTag->id])); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.productTag.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', $productTag->name)); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.productTag.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="imagen_tag"><?php echo e(trans('cruds.productTag.fields.imagen_tag')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('imagen_tag') ? 'is-invalid' : ''); ?>" id="imagen_tag-dropzone">
                </div>
                <?php if($errors->has('imagen_tag')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('imagen_tag')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.productTag.fields.imagen_tag_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tag_link"><?php echo e(trans('cruds.productTag.fields.tag_link')); ?></label>
                <input class="form-control <?php echo e($errors->has('tag_link') ? 'is-invalid' : ''); ?>" type="text" name="tag_link" id="tag_link" value="<?php echo e(old('tag_link', $productTag->tag_link)); ?>">
                <?php if($errors->has('tag_link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tag_link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.productTag.fields.tag_link_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tag_title"><?php echo e(trans('cruds.productTag.fields.tag_title')); ?></label>
                <input class="form-control <?php echo e($errors->has('tag_title') ? 'is-invalid' : ''); ?>" type="text" name="tag_title" id="tag_title" value="<?php echo e(old('tag_title', $productTag->tag_title)); ?>">
                <?php if($errors->has('tag_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tag_title')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.productTag.fields.tag_title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="tag_alt"><?php echo e(trans('cruds.productTag.fields.tag_alt')); ?></label>
                <input class="form-control <?php echo e($errors->has('tag_alt') ? 'is-invalid' : ''); ?>" type="text" name="tag_alt" id="tag_alt" value="<?php echo e(old('tag_alt', $productTag->tag_alt)); ?>">
                <?php if($errors->has('tag_alt')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tag_alt')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.productTag.fields.tag_alt_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.imagenTagDropzone = {
    url: '<?php echo e(route('admin.product-tags.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="imagen_tag"]').remove()
      $('form').append('<input type="hidden" name="imagen_tag" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="imagen_tag"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($productTag) && $productTag->imagen_tag): ?>
      var file = <?php echo json_encode($productTag->imagen_tag); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="imagen_tag" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/admin/productTags/edit.blade.php ENDPATH**/ ?>