<?php

return [
    'failed'   => 'Estas credenciales no coinciden con nuestros registros.',
    'throttle' => 'Muchos intentos para ingresar. Por favor intente de nuevo en :seconds segundos',
];
