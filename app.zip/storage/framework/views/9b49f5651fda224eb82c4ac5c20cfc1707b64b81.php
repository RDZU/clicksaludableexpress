<?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>






<div class="register-photo">
    <div class="form-container">
        <div class="image-holder"></div>
        <form action="<?php echo e(route('mensaje')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <h2 class="text-center"><strong>¿Dudas? ¿Consultas? Escribanos</strong></h2>
            <div class="form-group"><input required class="form-control" type="text" placeholder="Nombre / Razon social" name="name"></div>
            <div class="form-group"><input required class="form-control" type="email" name="email" placeholder="Email"></div>
            <div class="form-group"><input class="form-control" type="text" name="telefono" placeholder="Teléfono"></div>
            <div class="form-group"><select name="info_conocer" class="form-control"><optgroup label="¿Como nos Conoce?"></optgroup><option value="Publicidad" >Publicidad</option><option value="Redes Sociales">Redes Sociales</option><option value="Referido">Referido</option><option value="Internet">Internet</option></select></div>
            <div class="form-group"><select name="consulta" class="form-control"><optgroup label="¿Motivo de su Consulta?"><option value="Publicidad" selected="">Consulta</option><option value="Reclamos">Reclamos</option><option value="Otros" >Otros</option></optgroup></select></div>
    <div class="form-group"><textarea required  class="form-control form-control-sm d-inline" name="descripcion_consulta" rows="5" placeholder="Escriba su mensaje aquí..."></textarea></div>
<div class="form-group"><input value="Enviar Consulta "class="btn btn-success btn-block" type="submit"></div>
</form>
</div>
</div>


<?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/contacto.blade.php ENDPATH**/ ?>