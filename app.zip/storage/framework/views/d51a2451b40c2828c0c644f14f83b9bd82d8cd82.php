<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.marca.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.marcas.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="name"><?php echo e(trans('cruds.marca.fields.name')); ?></label>
                <input class="form-control <?php echo e($errors->has('name') ? 'is-invalid' : ''); ?>" type="text" name="name" id="name" value="<?php echo e(old('name', '')); ?>" required>
                <?php if($errors->has('name')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('name')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.name_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="descripcion"><?php echo e(trans('cruds.marca.fields.descripcion')); ?></label>
                <textarea class="form-control <?php echo e($errors->has('descripcion') ? 'is-invalid' : ''); ?>" name="descripcion" id="descripcion"><?php echo e(old('descripcion')); ?></textarea>
                <?php if($errors->has('descripcion')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('descripcion')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.descripcion_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image"><?php echo e(trans('cruds.marca.fields.image')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>" id="image-dropzone">
                </div>
                <?php if($errors->has('image')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.image_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_link"><?php echo e(trans('cruds.marca.fields.image_link')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_link') ? 'is-invalid' : ''); ?>" type="text" name="image_link" id="image_link" value="<?php echo e(old('image_link', '')); ?>">
                <?php if($errors->has('image_link')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_link')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.image_link_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_title"><?php echo e(trans('cruds.marca.fields.image_title')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_title') ? 'is-invalid' : ''); ?>" type="text" name="image_title" id="image_title" value="<?php echo e(old('image_title', '')); ?>">
                <?php if($errors->has('image_title')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_title')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.image_title_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="image_alt"><?php echo e(trans('cruds.marca.fields.image_alt')); ?></label>
                <input class="form-control <?php echo e($errors->has('image_alt') ? 'is-invalid' : ''); ?>" type="text" name="image_alt" id="image_alt" value="<?php echo e(old('image_alt', '')); ?>">
                <?php if($errors->has('image_alt')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('image_alt')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.image_alt_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="slug"><?php echo e(trans('cruds.marca.fields.slug')); ?></label>
                <input class="form-control <?php echo e($errors->has('slug') ? 'is-invalid' : ''); ?>" type="text" name="slug" id="slug" value="<?php echo e(old('slug', '')); ?>">
                <?php if($errors->has('slug')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('slug')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.slug_helper')); ?></span>
            </div>
            <div class="form-group">
                <label><?php echo e(trans('cruds.marca.fields.visible_home')); ?></label>
                <select class="form-control <?php echo e($errors->has('visible_home') ? 'is-invalid' : ''); ?>" name="visible_home" id="visible_home">
                    <option value disabled <?php echo e(old('visible_home', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Models\Marca::VISIBLE_HOME_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('visible_home', '') === (string) $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('visible_home')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('visible_home')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.marca.fields.visible_home_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.imageDropzone = {
    url: '<?php echo e(route('admin.marcas.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="image"]').remove()
      $('form').append('<input type="hidden" name="image" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="image"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($marca) && $marca->image): ?>
      var file = <?php echo json_encode($marca->image); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="image" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clicksaludableexpress.com\resources\views/admin/marcas/create.blade.php ENDPATH**/ ?>